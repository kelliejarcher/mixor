mixord <- function(...)
{
    .Deprecated("mixor", package="mixor")
}