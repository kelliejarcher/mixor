BIC.mixor <-
function(object, ...) {
	object$SBCD
}
