coef.mixor <-
function(object,...) {
object$Model[,"Estimate"]
}
