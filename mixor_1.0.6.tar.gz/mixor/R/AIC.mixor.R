AIC.mixor <-
function(object, ...) {
  object$AICD
}
