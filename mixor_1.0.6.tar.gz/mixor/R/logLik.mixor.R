logLik.mixor <-
function(object, ...) {
 object$RLOGL
}
