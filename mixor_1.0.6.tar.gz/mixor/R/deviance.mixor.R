deviance.mixor <-
function(object, ...) {
	object$Deviance
}
